# 2 장 Pandas
* 데이터 처리와 분석을 위한 라이브러리

* 행과 열로 이루어진 데이터 객체를 만들어 다룰 수 있음

* 대용량의 데이터들을 처리하는데 매우 편리

* pandas 자료구조

 **Series: 1차원
 ** DataFrame: 2차원
 **Panel: 3차원
* pandas 로딩


```python
import numpy as np # 보통 numpy와 함께 import
import pandas as pd
```

# 2.1 Pandas DataFrame
* 2차원 자료구조

* 행레이블/열레이블, 데이터로 구성됨

* 딕셔너리(dictionary)에서 데이터프레임 생성


```python
import pandas as pd
# 딕셔너리
data = {
    'year':[2016, 2017, 2018],
    'GDP rate': [2.8, 3.1, 3.0],
    'GDP': ['1.637M', '1.73M', '1.83M' ]
}
df = pd.DataFrame(data, index=data['year']) # index추가할 수 있음
print(df)
```

          year  GDP rate     GDP
    2016  2016       2.8  1.637M
    2017  2017       3.1   1.73M
    2018  2018       3.0   1.83M
    


```python
print("row labels:", df.index)
```

    row labels: Index([2016, 2017, 2018], dtype='int64')
    


```python
print("column labels:", df.columns)
```

    column labels: Index(['year', 'GDP rate', 'GDP'], dtype='object')
    


```python
print("head:", df.head()) # print some lines in data
```

    head:       year  GDP rate     GDP
    2016  2016       2.8  1.637M
    2017  2017       3.1   1.73M
    2018  2018       3.0   1.83M
    

* csv 파일에서 데이터프레임 생성


```python
csv_data_df = pd.read_csv("C:/Users/user/Desktop/r practice/pop2019.csv")
print(csv_data_df.head())
```

       sido_code   sido  sigungu_code sigungu sigungu2   total    male  female  \
    0         11  서울특별시         11110     종로구       JR  151290   73746   77544   
    1         11  서울특별시         11140      중구        J  126171   61910   64261   
    2         11  서울특별시         11170     용산구       YS  228670  110356  118314   
    3         11  서울특별시         11200     성동구       SD  300889  147273  153616   
    4         11  서울특별시         11215     광진구       KJ  351350  170262  181088   
    
       rep_n    income     gain    tax_t  cmp_tax  reduce  cnf_tax  cafes isCity  
    0  29540   5518807  1963230  1804064   543327   80539   462788     96   도시지역  
    1  25490   4621063  1188870  1060615   278268   36464   241804    149   도시지역  
    2  47229  11627137  5650993  5309143  1810026  271409  1538617     77   도시지역  
    3  55769   9113764  2316783  2020332   478784   65972   412812     95   도시지역  
    4  65366   8457432  2049636  1737870   367360   51654   315706    111   도시지역  
    


```python
print(csv_data_df.columns)
```

    Index(['sido_code', 'sido', 'sigungu_code', 'sigungu', 'sigungu2', 'total',
           'male', 'female', 'rep_n', 'income', 'gain', 'tax_t', 'cmp_tax',
           'reduce', 'cnf_tax', 'cafes', 'isCity'],
          dtype='object')
    

* 특정 변수의 추출


```python
#df에서 year변수의 값 추출
print(df['year']) 
# 또는 
```

    2016    2016
    2017    2017
    2018    2018
    Name: year, dtype: int64
    

* 부분추출


```python
print(csv_data_df[["sido", 'male']]) # DataFrame
```

            sido    male
    0      서울특별시   73746
    1      서울특별시   61910
    2      서울특별시  110356
    3      서울특별시  147273
    4      서울특별시  170262
    ..       ...     ...
    224     경상남도   19097
    225     경상남도   30345
    226     경상남도   21655
    227  제주특별자치도  245533
    228  제주특별자치도   91812
    
    [229 rows x 2 columns]
    


```python
print(csv_data_df.loc[:3, ['sido', 'male']])
```

        sido    male
    0  서울특별시   73746
    1  서울특별시   61910
    2  서울특별시  110356
    3  서울특별시  147273
    


```python
print(csv_data_df.iloc[:3, :3])
```

       sido_code   sido  sigungu_code
    0         11  서울특별시         11110
    1         11  서울특별시         11140
    2         11  서울특별시         11170
    


```python
print (csv_data_df[csv_data_df['sido'] == '경상남도']) # 부울 인덱싱
```

         sido_code  sido  sigungu_code sigungu sigungu2    total    male  female  \
    209         48  경상남도         48120     창원시     none  1044740  529262  515478   
    210         48  경상남도         48170     진주시     none   347334  171834  175500   
    211         48  경상남도         48220     통영시     none   131404   66053   65351   
    212         48  경상남도         48240     사천시     none   111925   56451   55474   
    213         48  경상남도         48250     김해시     none   542455  274336  268119   
    214         48  경상남도         48270     밀양시     none   105552   51618   53934   
    215         48  경상남도         48310     거제시     none   248276  130141  118135   
    216         48  경상남도         48330     양산시     none   350759  176114  174645   
    217         48  경상남도         48720     의령군     none    27168   13242   13926   
    218         48  경상남도         48730     함안군     none    65700   33203   32497   
    219         48  경상남도         48740     창녕군     none    62331   31015   31316   
    220         48  경상남도         48820     고성군     none    52276   26208   26068   
    221         48  경상남도         48840     남해군     none    43622   20988   22634   
    222         48  경상남도         48850     하동군     none    46574   23149   23425   
    223         48  경상남도         48860     산청군     none    35417   17321   18096   
    224         48  경상남도         48870     함양군     none    39637   19097   20540   
    225         48  경상남도         48880     거창군     none    62179   30345   31834   
    226         48  경상남도         48890     합천군     none    45204   21655   23549   
    
          rep_n    income     gain    tax_t  cmp_tax  reduce  cnf_tax  cafes  \
    209  129306  21777762  3751042  3068959   627296  125060   502236    320   
    210   40451   7113171  1232982  1012462   209180   35043   174137    156   
    211   16800   2855532   365837   286715    48746    9768    38978     42   
    212   11539   1882553   285168   227257    40355    7218    33137     48   
    213   72080  13075331  1903081  1518807   274617   72707   201911    171   
    214   10406   1498652   231510   181594    30886    7264    23623     42   
    215   33050   4215609   923265   715490   118124   27944    90180     70   
    216   45791   7118010  1087469   853227   151210   35050   116160    111   
    217    2093    287873    42135    32621     4883    1369     3514      6   
    218    7160   1243444   173432   137944    25317    5839    19478     11   
    219    5672   1018056   122709    95927    15738    3635    12103     13   
    220    5045    693842    96829    74429    11836    2724     9112      3   
    221    3737    566807    83350    66285    12140    2104    10036     15   
    222    3935    524450    80254    62224    10171    2169     8002      7   
    223    3118    430690    63283    48637     7199    1515     5684      9   
    224    3405    489995    74574    59162     9908    2005     7903      6   
    225    5804    874419   138446   109515    19072    3456    15615     16   
    226    3303    520636    76381    60736     9884    1963     7920      6   
    
        isCity  
    209   도시지역  
    210   도시지역  
    211   도시지역  
    212   도시지역  
    213   도시지역  
    214   도시지역  
    215   도시지역  
    216   도시지역  
    217  비도시지역  
    218  비도시지역  
    219  비도시지역  
    220  비도시지역  
    221  비도시지역  
    222  비도시지역  
    223  비도시지역  
    224  비도시지역  
    225  비도시지역  
    226  비도시지역  
    


```python
print(csv_data_df['female'].sum())
```

    25985045
    


```python
print (df.describe()) # describe( )를 통해 기본적인 통계치를 모두 표시
```

             year  GDP rate
    count     3.0  3.000000
    mean   2017.0  2.966667
    std       1.0  0.152753
    min    2016.0  2.800000
    25%    2016.5  2.900000
    50%    2017.0  3.000000
    75%    2017.5  3.050000
    max    2018.0  3.100000
    


```python
print(csv_data_df.describe())
```

           sido_code  sigungu_code         total           male         female  \
    count  229.00000    229.000000  2.290000e+02     229.000000     229.000000   
    mean    37.20524  37664.908297  2.264186e+05  112946.794760  113471.812227   
    std     11.61392  11691.947934  2.221152e+05  110695.712722  111510.431000   
    min     11.00000  11110.000000  9.617000e+03    5230.000000    4387.000000   
    25%     28.00000  28710.000000  5.280500e+04   26309.000000   26695.000000   
    50%     42.00000  42730.000000  1.483790e+05   73746.000000   75385.000000   
    75%     46.00000  46730.000000  3.454690e+05  170262.000000  172958.000000   
    max     50.00000  50130.000000  1.194465e+06  601410.000000  593055.000000   
    
                   rep_n        income          gain         tax_t       cmp_tax  \
    count     229.000000  2.290000e+02  2.290000e+02  2.290000e+02  2.290000e+02   
    mean    32618.493450  4.984429e+06  1.021670e+06  8.527116e+05  1.812293e+05   
    std     36248.931927  5.799952e+06  1.589928e+06  1.419821e+06  3.935473e+05   
    min       997.000000  1.395460e+05  2.033200e+04  1.587700e+04  2.131000e+03   
    25%      4978.000000  7.565650e+05  1.067690e+05  8.366800e+04  1.395100e+04   
    50%     18497.000000  2.855532e+06  4.658830e+05  3.653020e+05  6.140600e+04   
    75%     48514.000000  7.113171e+06  1.330195e+06  1.075329e+06  2.091800e+05   
    max    186450.000000  3.506265e+07  1.416290e+07  1.325722e+07  4.125313e+06   
    
                  reduce       cnf_tax       cafes  
    count     229.000000  2.290000e+02  229.000000  
    mean    30141.200873  1.510881e+05   63.554585  
    std     51049.346697  3.439888e+05   71.191753  
    min       454.000000  1.676000e+03    0.000000  
    25%      2763.000000  1.105500e+04   13.000000  
    50%     12954.000000  4.948000e+04   42.000000  
    75%     36252.000000  1.666690e+05   95.000000  
    max    467534.000000  3.657779e+06  478.000000  
    

* 빈도


```python
# One-way contingency table
x=pd.crosstab(index=csv_data_df.sido, columns="count", margins=True)
print(x)
```

    col_0    count  All
    sido               
    강원도         18   18
    경기도         31   31
    경상남도        18   18
    경상북도        23   23
    광주광역시        5    5
    대구광역시        8    8
    대전광역시        5    5
    부산광역시       16   16
    서울특별시       25   25
    세종특별자치시      1    1
    울산광역시        5    5
    인천광역시       10   10
    전라남도        22   22
    전라북도        14   14
    제주특별자치도      2    2
    충청남도        15   15
    충청북도        11   11
    All        229  229
    


```python
print('type of x=',type(x))
```

    type of x= <class 'pandas.core.frame.DataFrame'>
    


```python
print(x['count'])
# Two-way contingency table
```

    sido
    강원도         18
    경기도         31
    경상남도        18
    경상북도        23
    광주광역시        5
    대구광역시        8
    대전광역시        5
    부산광역시       16
    서울특별시       25
    세종특별자치시      1
    울산광역시        5
    인천광역시       10
    전라남도        22
    전라북도        14
    제주특별자치도      2
    충청남도        15
    충청북도        11
    All        229
    Name: count, dtype: int64
    


```python
pd.crosstab(csv_data_df.sido, csv_data_df.female, margins=True)
# Three-way contingency table
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>female</th>
      <th>4387</th>
      <th>8574</th>
      <th>8888</th>
      <th>10682</th>
      <th>11276</th>
      <th>11422</th>
      <th>11677</th>
      <th>12213</th>
      <th>12722</th>
      <th>12731</th>
      <th>...</th>
      <th>352166</th>
      <th>392926</th>
      <th>416702</th>
      <th>417496</th>
      <th>476080</th>
      <th>515478</th>
      <th>533663</th>
      <th>543602</th>
      <th>593055</th>
      <th>All</th>
    </tr>
    <tr>
      <th>sido</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>강원도</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>18</td>
    </tr>
    <tr>
      <th>경기도</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>31</td>
    </tr>
    <tr>
      <th>경상남도</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>18</td>
    </tr>
    <tr>
      <th>경상북도</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>23</td>
    </tr>
    <tr>
      <th>광주광역시</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>대구광역시</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>대전광역시</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>부산광역시</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>16</td>
    </tr>
    <tr>
      <th>서울특별시</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>25</td>
    </tr>
    <tr>
      <th>세종특별자치시</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>울산광역시</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>인천광역시</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>10</td>
    </tr>
    <tr>
      <th>전라남도</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>22</td>
    </tr>
    <tr>
      <th>전라북도</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>14</td>
    </tr>
    <tr>
      <th>제주특별자치도</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>충청남도</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>15</td>
    </tr>
    <tr>
      <th>충청북도</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>11</td>
    </tr>
    <tr>
      <th>All</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>229</td>
    </tr>
  </tbody>
</table>
<p>18 rows × 230 columns</p>
</div>



# 2.2 Pandas 통계처리

df.sum(),
df.sum(axis='columns'),
df.mean(axis='columns', skipna=False),
df.cumsum()

# 2.3 Pandas plot
1. Boxplot


```python
df = pd.DataFrame({
         'unif': np.random.uniform(-3, 3, 20),
         'norm': np.random.normal(0, 1, 20)
    })
print(df.head())    
```

           unif      norm
    0 -0.745113 -0.546763
    1  2.452686 -1.517222
    2 -1.966202  0.452489
    3  2.452092 -1.969313
    4 -1.574953 -0.668132
    


```python
df.boxplot(column=['unif', 'norm'])
```




    <Axes: >




    
![png](output_29_1.png)
    


2. time series plot


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.DataFrame({
         'unif': np.random.uniform(-3, 3, 20),
         'norm': np.random.normal(0, 1, 20)
    })
# 플로팅
df.plot()
plt.show()

```


    
![png](output_31_0.png)
    

